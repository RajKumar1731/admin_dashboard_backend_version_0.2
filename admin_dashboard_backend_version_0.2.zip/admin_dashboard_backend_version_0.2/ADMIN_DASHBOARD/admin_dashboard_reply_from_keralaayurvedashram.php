<?php session_start();?>
<?php if(!isset($_SESSION['valid'])) {
			header('Location:admin_dashboard_index.php');			
		}
		?>
<?php 
$dsn="mysql:host=localhost; dbname=put_your_database";
$username="root";
$password="put_your_password"; 
try{
	$connection=new PDO($dsn, $username, $password);
	$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){
	echo "Query Failed." . $e->getMessage();
}
if(isset($_POST['submit'])){
	$client_mail=$_POST['client_mail'];
	$reply=$_POST['reply'];
	$loginID=$_SESSION['id'];
$insert="INSERT INTO currentreply(id,client_mail,reply,login_id) VALUES(:id, :client_mail,:reply,:loginID)";
$statement=$connection->prepare($insert);
$statement->bindValue(':id', $id, PDO::PARAM_STR);
$statement->bindValue(':client_mail', $client_mail, PDO::PARAM_STR);
$statement->bindValue(':reply', $reply, PDO::PARAM_STR);
$statement->bindValue(":loginID", $loginID, PDO::PARAM_INT);
$statement->execute();
}
?>
<?php
/* Set e-mail recipient */
$myemail  = "$client_mail";
/* Check all form inputs using check_input function */
$subject  = "Reply of your current communication";
$client_mail    = check_input($_POST['client_mail']);
$reply = check_input($_POST['reply'], "reply");
/* If e-mail is not valid show error message */
if (!preg_match("/([\w\-]+\@[\w\-]+\.[\w\-]+)/", $client_mail))
{
    show_error("E-mail address not valid");
}
/* If URL is not valid set $website to empty */
/* Let's prepare the message for the e-mail */
$message = "Hello!
Reply of your current health related communication :
Subject: $subject
E-mail: $client_mail
Reply:$reply
End of message
";
/* Send the message using mail() function */
mail($myemail, $subject, $message);
/* Redirect visitor to the thank you page */
ob_start();
header('Location:admin_dashboard_home.php');
exit();
/* Functions we used */
function check_input($data, $problem='')
{
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    if ($problem && strlen($data) == 0)
    {
        show_error($problem);
    }
    return $data;
}
function show_error($myError)
{
?>
    <html>
    <body>
    <b>Please correct the following error:</b><br />
    <?php echo $myError; ?>
    </body>
    </html>
<?php
exit();
}
?>