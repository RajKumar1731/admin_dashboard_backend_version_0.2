<?php 
session_start();
session_destroy();
header('location:admin_dashboard_index.php');
?>