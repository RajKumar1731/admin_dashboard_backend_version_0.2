<?php 
$dsn="mysql:host=localhost; dbname=put_your_database";
$username="root";
$password="put_your_password"; 
try{
	$connection=new PDO($dsn, $username, $password);
	$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){
	echo "Query Failed." . $e->getMessage();
}
if(isset($_POST["submit"]) && $_POST['admin_name'] && $_POST['admin_email'] && $_POST['admin_password'] && $_POST['admin_contact_number']) {
$admin_name=$_POST['admin_name'];
$admin_email=$_POST['admin_email'];
$admin_password=$_POST['admin_password'];
$admin_hashed_password=password_hash($admin_password, PASSWORD_DEFAULT);
$admin_contact_number=$_POST['admin_contact_number'];
$insert_query="INSERT INTO admindashboardsignup (id, admin_name, admin_email, admin_hashed_password, admin_contact_number) 
VALUES('$id', '$admin_name', '$admin_email', '$admin_hashed_password', '$admin_contact_number')";
$connection->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
$statement=$connection->prepare($insert_query);
$statement->bindValue(':id', $id, PDO::PARAM_STR);
$statement->bindValue(':admin_name', $admin_name, PDO::PARAM_STR);
$statement->bindValue(':admin_email', $admin_email, PDO::PARAM_STR);
$statement->bindValue(':admin_hashed_password', $admin_hashed_password, PDO::PARAM_STR);
$statement->bindValue(':admin_contact_number', $admin_contact_number, PDO::PARAM_STR);
$statement->execute();
	}else{
		echo "Sorry, there was a problem uploading your file.";
	}
	//--reports end--//
ob_start();
header('location:admin_dashboard_thanks.html');
?>

