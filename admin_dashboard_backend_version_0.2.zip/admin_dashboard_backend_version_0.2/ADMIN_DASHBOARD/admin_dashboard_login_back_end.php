<?php session_start();?>
<?php 
$dsn="mysql:host=localhost; dbname=put_your_database";
$username="root";
$password="put_your_password"; 
try{
	$connection=new PDO($dsn, $username, $password);
	$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){
	echo "Query Failed." . $e->getMessage();
}
if(isset($_POST['submit']) && ($_POST['admin_email']) && ($_POST['admin_password'])){
$admin_email=$_POST['admin_email'];
$admin_password=$_POST['admin_password'];
}
$output=$connection->prepare("SELECT * FROM admindashboardsignup WHERE admin_email=:admin_email");
$output->bindValue(":admin_email", $admin_email, PDO::PARAM_STR);
$output->execute();
$row=$output->fetch();
	$a=$row['admin_email'];
	$b=$row['admin_hashed_password'];	
if(password_verify($admin_password, $b)){
if($admin_email===$a){
header('location:admin_dashboard_home.php');	
}
else{
	echo "either email or password is wrong.";
}
}
if(is_array($row) && !empty($row)) {
			$validuser = $row['admin_email'];
			$_SESSION['valid'] = $validuser;
			
		//	$_SESSION['name'] = $row['name'];
			$_SESSION['id'] = $row['id'];
			
		} else {
			echo "Invalid email or password.";
			echo "<br/>";
			echo "<a href='admin_dashboard_index.php'>Go back</a>";
		}
		if(!isset($_SESSION['valid'])) {
			header('Location:admin_dashboard_index.php');			
		}
?>
