<!DOCTYPE html>
<html  lang="en">
<head>
<meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">
    <title>admin dashboard index</title>
    <!-- Bootstrap core CSS -->
    <link href="css_admin_dashboard/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="css_admin_dashboard/bootstrap-theme.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css_admin_dashboard/theme.css" rel="stylesheet">
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="keyword" content="indoscie, Indegenous Science & Technology">
<meta name="description" content=" project by http://www.indoscie.com/ ">
<link rel="stylesheet" type="text/css" href="css_admin_dashboard/responsiveformone.css">
<link rel="stylesheet" media="screen and (max-width: 1200px) and (min-width: 601px)" href="css_admin_dashboard/responsiveform11.css" />
<link rel="stylesheet" media="screen and (max-width: 600px) and (min-width: 351px)" href="css_admin_dashboard/responsiveform21.css" />
<link rel="stylesheet" media="screen and (max-width: 350px)" href="css_admin_dashboard/responsiveform31.css" />
<link rel="stylesheet" href="css_admin_dashboard/style.css">
</head>

<body>
    <div class="container-fluid">
<div class="row"> 
<div class="col-md-12">
  <ul class="nav nav-tabs">
	<li class="active"><a href="#">Home</a></li>
    <li class="active"><a href="#">Address</a></li>
    <li class="active"><a href="#">Appointment</a></li>
    <li class="active"><a href="#">General Consultation</a></li>
    <li class="active"><a href="#">Cancer Consultation</a></li>
    </ul>
    </div></div></div>
<div class="container-fluid">
<div class="row"> 
<div class="col-md-6">
<div id="envelope">
<h1>Login</h1>
<form action="admin_dashboard_login_back_end.php" method="post" enctype="multipart/form-data">
<p><b>E-mail :</b> <input type="text" name="admin_email"/></br> 
<b>Password :</b> <input type="text" name="admin_password"/><br/></p>
<p><input type="submit" name="submit" class="rainbow_border" value="Send it!"></p>
</form>
</div>
</div>
<div class="col-md-6">
<div id="envelope">
<h1>Signup</h1>
<form action="admin_dashboard_signup_back_end.php" method="post" enctype="multipart/form-data">
<p><b>Name :</b> <input type="text" name="admin_name"/><br/>
<b>E-mail :</b> <input type="text" name="admin_email"/><br/>
<b>Password :</b> <input type="text" name="admin_password"/><br/>
<b>Contact Number :</b> <input type="text" name="admin_contact_number"/><br/></p>
<p><input type="submit" name="submit" class="rainbow_border" value="Send it!"></p>
</form>
</div>
</div>
<p class="text-center"><a href="#"> << Home </a></p>
</div>
<!--end container-fluid-->
    <!-- Bootstrap core JavaSc
   </div> <!-- /container -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js_admin_dashboard/bootstrap.min.js"></script>
    <script src="js_admin_dashboard/docs.min.js"></script>	
	<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
  </body>
</html>

