<!DOCTYPE html>
<html  lang="en">
<head>
<meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">
    <title>clientside dashboard frontend</title>
    <!-- Bootstrap core CSS -->
    <link href="css_admin_dashboard/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="css_admin_dashboard/bootstrap-theme.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css_admin_dashboard/theme.css" rel="stylesheet">
    <!--[if lt IE 9]><script src="../../assets/js/ie8-responsive-file-warning.js"></script><![endif]-->
    <script src="../../assets/js/ie-emulation-modes-warning.js"></script>
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="keyword" content="indoscie, Indegenous Science & Technology">
<meta name="description" content=" project by http://www.indoscie.com/ ">
<link rel="stylesheet" type="text/css" href="css_admin_dashboard/responsiveformone.css">
<link rel="stylesheet" media="screen and (max-width: 1200px) and (min-width: 601px)" href="css_admin_dashboard/responsiveform11.css" />
<link rel="stylesheet" media="screen and (max-width: 600px) and (min-width: 351px)" href="css_admin_dashboard/responsiveform21.css" />
<link rel="stylesheet" media="screen and (max-width: 350px)" href="css_admin_dashboard/responsiveform31.css" />
<link rel="stylesheet" href="css_admin_dashboard/style.css">
</head>

<body>
    <div class="container-fluid">
<div class="row"> 
<div class="col-md-12">
    <ul class="nav nav-tabs">
	<li class="active"><a href="#">Home</a></li>
    <li class="active"><a href="#">Address</a></li>
    <li class="active"><a href="#">Appointment</a></li>
    <li class="active"><a href="#">General Consultation</a></li>
    <li class="active"><a href="#">Cancer Consultation</a></li>
  </ul>
    </div></div></div>
<div class="container-fluid">
<div class="row"> 
<div class="col-md-12">
<div id="envelope">
<h1>Patient_dashboard_frontend</h1>
<form action="clientside_dashboard_backend.php" method="post" enctype="multipart/form-data">
<p>
<b>Name:</b> <input type="text" name="name"/><br/>
<b>Subject:</b> <input type="text" name="subject" /><br/>
<b>E-mail:</b> <input type="text" name="email"/><br/>
<b>Contact Number:</b> <input type="text" name="contact_number"/><br/></p>
<p><b>Please describe your health related problem:</b><br/>
<textarea name="comment" rows="3" cols="40"></textarea><br/>
<b>Select case paper/reports-1 to upload (if any):</b><br/>
<input type="file" name="report_one" id="reports">
<b>Select case paper/reports-2 to upload (if any):</b><br/>
<input type="file" name="report_two" id="reports"><br/></p>
<p style="background-color:white; padding:10px; color:red;">
You are highly recommended to send your previous case paper of your treatment/disease to this email address: drcrystalayurveda@gmail.com </p>
<p><input type="submit" name="submit" class="rainbow_border" value="Send it!"></p>
</form>
</div>
</div>
<p class="text-center"><a href="#"> << Home </a></p>
</div>
<!--end container-fluid-->
    <!-- Bootstrap core JavaSc
   </div> <!-- /container -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="js_admin_dashboard/bootstrap.min.js"></script>
    <script src="js_admin_dashboard/docs.min.js"></script>	
	<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>
  </body>
</html>

