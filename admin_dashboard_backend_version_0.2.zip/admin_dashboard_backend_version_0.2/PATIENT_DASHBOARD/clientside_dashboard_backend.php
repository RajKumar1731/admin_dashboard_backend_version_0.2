<?php 
$dsn="mysql:host=localhost; dbname=put_your_database";
$username="root";
$password="put_your_password"; 
try{
	$connection=new PDO($dsn, $username, $password);
	$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){
	echo "Query Failed." . $e->getMessage();
}
$folderone = "case_paper_one/";
# $upload_image = $folder . basename($_FILES["fileToUpload"]["name"]);
$case_paper_path_one = $folderone . basename($_FILES["report_one"]["name"]);
$foldertwo = "case_paper_two/";
# $upload_image = $folder . basename($_FILES["fileToUpload"]["name"]);
$case_paper_path_two = $foldertwo . basename($_FILES["report_two"]["name"]);
if(isset($_POST["submit"]) && $_POST['name'] && $_POST['subject'] && $_POST['email'] && $_POST['contact_number'] && $_POST['comment']) {
if (move_uploaded_file($_FILES["report_one"]["tmp_name"], $case_paper_path_one)) {
echo "The file ". basename( $_FILES["report_one"]["name"]). " has been uploaded successfully." . "<br>";
}else{
	echo "Failed to upload proof of treatment bill" . "<br>";
}
if (move_uploaded_file($_FILES["report_two"]["tmp_name"], $case_paper_path_two)) {
echo "The file ". basename( $_FILES["report_two"]["name"]). " has been uploaded successfully." . "<br>";
echo "Thank You." . "<br>";
}
else{
	echo "Failed to upload appointment letter or case paper" . "<br>";
}

$name=$_POST['name'];
$subject=$_POST['subject'];
$email=$_POST['email'];
$contact_number=$_POST['contact_number'];
$comment=$_POST['comment'];
$insert_query="INSERT INTO casepaper (id, name, subject, email, contact_number, comment, case_paper_path_one, case_paper_path_two) 
VALUES('$id', '$name', '$subject', '$email', '$contact_number', '$comment', '$case_paper_path_one', '$case_paper_path_two')";
$connection->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
$statement=$connection->prepare($insert_query);
$statement->bindValue(':id', $id, PDO::PARAM_STR);
$statement->bindValue(':name', $name, PDO::PARAM_STR);
$statement->bindValue(':subject', $subject, PDO::PARAM_STR);
$statement->bindValue(':email', $email, PDO::PARAM_STR);
$statement->bindValue(':contact_number', $contact_number, PDO::PARAM_STR);
$statement->bindValue(':comment', $comment, PDO::PARAM_STR);
$statement->bindValue(':case_paper_path_one', $case_paper_path_one, PDO::PARAM_STR);
$statement->bindValue(':case_paper_path_two', $case_paper_path_two, PDO::PARAM_STR);
$statement->execute();
	}else{
		echo "Sorry, there was a problem uploading your file.";
	}
	//--reports end--//
ob_start();
header('location:thanks.html');
?>

