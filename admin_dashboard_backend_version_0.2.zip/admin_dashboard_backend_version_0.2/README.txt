Hello Guys...
This is admin dahboard for very beginner to learn all about signup/registration & login mechanism.
You will get familiar with few CRUD operation also in some of the part.
You must visit this page [ admin_dashboard_databases.html] to know all about database and tables. Skip the table which is not useful to you.

Project Name is: admin_dashboard_backend_version_0.2
Total Folder in this project is two:
1) ADMIN_DASHBOARD & 
2) PATIENT_DASHBOARD

Total files in this project is as follows:

1) ADMIN_DASHBOARD
SUB_FOLDER: [1. css_admin_dashboard, 2. fonts_admin_dashboard & 3. js_admin_dashboard]
1.admin_dashboard_databases.html
2.admin_dashboard_history.php
3.admin_dashboard_home.php
4.admin_dashboard_index.php
5.admin_dashboard_log_out.php
6.admin_dashboard_login_back_end.php
7.admin_dashboard_reply_from_keralaayurvedashram &
8. admin_dashboard_thanks

2) PATIENT_DASHBOARD
SUB_FOLDER: [1.case_paper_one, 2. case_paper_two, 3. css_admin_dashboard, 4.fonts_admin_dashboard & js_admin_dashboard]
1.clientside_dashboard_backend.php
2.client_dashboard_frontend & 
3.thanks.html

Note: 1.) This project is targeted to new comer in field of IT sector. Please don't use in real project as it is having full with
 security concirn. It is just for study/learning purpose. 
2.) Time to time we will keep updating this project to simplyfy your problems.
If you get stuck somewhere please get in touch with us and let me know just here:
http://www.indoscie.com/
email: raj.ece1731@gmail.com & contact Number: +91-9765280961
facebook profile: https://www.facebook.com/rajkumar.vishwakarma.7568
linkedIn profile: https://www.linkedin.com/in/rajkumar-vishwakarma-65959612a/
quora Profile: https://www.quora.com/profile/Rajkumar-Vishwakarma-32

Thanks


